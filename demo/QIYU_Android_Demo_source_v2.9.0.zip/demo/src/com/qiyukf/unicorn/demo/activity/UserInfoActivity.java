package com.qiyukf.unicorn.demo.activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.qiyukf.unicorn.api.Unicorn;
import com.qiyukf.unicorn.api.YSFUserInfo;
import com.qiyukf.unicorn.demo.R;
import com.qiyukf.unicorn.demo.utils.DemoPreferences;
import com.qiyukf.unicorn.demo.utils.Utils;

import java.util.ArrayList;
import java.util.List;

public class UserInfoActivity extends BaseActivity implements AdapterView.OnItemClickListener {
    private TextView tvAccount;
    private ListView lvAccount;
    private Button btnLogout;
    private AccountAdapter mAdapter;
    private List<YSFUserInfo> mAccounts;
    private ProgressDialog mProgressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);

        tvAccount = (TextView) findViewById(R.id.tv_account);
        lvAccount = (ListView) findViewById(R.id.lv_account);
        btnLogout = (Button) findViewById(R.id.btn_logout);

        init();
    }

    private void init() {
        mAccounts = accounts();

        String userId = DemoPreferences.getYsfUserId();
        YSFUserInfo account = getAccount(mAccounts, userId);
        if (account != null) {
            mAccounts = removeAccount(mAccounts, account);
            tvAccount.setText("当前帐号：" + account.userId);
            btnLogout.setVisibility(View.VISIBLE);
        }

        mAdapter = new AccountAdapter(this);
        mAdapter.setData(mAccounts);
        lvAccount.setAdapter(mAdapter);
        lvAccount.setOnItemClickListener(this);
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setMessage("正在切换…");
        mProgressDialog.setCancelable(false);
    }

    public void onClick(View v) {
        onLogout();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
        mProgressDialog.show();
        final YSFUserInfo account = mAccounts.get(position);
        if (!account.userId.equals(DemoPreferences.getYsfUserId())) {
            // 切换帐号前需要先注销
            Unicorn.setUserInfo(null);
        }

        // 为防止数据紊乱，切换前后都延时1s
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                final YSFUserInfo account = mAccounts.get(position);
                mAccounts = accounts();
                mAccounts = removeAccount(mAccounts, account);

                if (Unicorn.isServiceAvailable()) {
                    mProgressDialog.cancel();

                    if (Unicorn.setUserInfo(account)) {
                        DemoPreferences.saveYsfUserId(account.userId);


                        tvAccount.setText("当前帐号：" + account.userId);
                        mAdapter.setData(mAccounts);
                        mAdapter.notifyDataSetChanged();
                        btnLogout.setVisibility(View.VISIBLE);
                        Toast.makeText(UserInfoActivity.this, "已切换为" + account.userId, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(UserInfoActivity.this, "用户资料格式不对", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    mHandler.postDelayed(this, 1500);
                }
            }
        }, 1500);
    }

    private void onLogout() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("确认注销");
        dialog.setMessage("注销后返回至匿名帐号，确定要注销吗");
        dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mAccounts = accounts();
                tvAccount.setText("当前帐号：匿名用户");
                mAdapter.setData(mAccounts);
                mAdapter.notifyDataSetChanged();
                btnLogout.setVisibility(View.GONE);
                Toast.makeText(UserInfoActivity.this, "注销成功", Toast.LENGTH_SHORT).show();

                Unicorn.setUserInfo(null);
                DemoPreferences.saveYsfUserId(null);
            }
        });
        dialog.setNegativeButton("取消", null);
        dialog.show();
    }

    private List<YSFUserInfo> accounts() {
        List<YSFUserInfo> accounts = new ArrayList<>();

        YSFUserInfo userInfoA = new YSFUserInfo();
        userInfoA.userId = "边晨";
        userInfoA.data = userInfoData("边晨", "13805713536", "bianchen@163.com", "已认证", "622202******01116068", "七鱼宝(2016010701)").toJSONString();
        accounts.add(userInfoA);

        YSFUserInfo userInfoB = new YSFUserInfo();
        userInfoB.userId = "欧阳";
        userInfoB.data = userInfoData("欧阳", "13511250981", "ouyang@163.com", "未认证", "622202******01110520", "七鱼银票(2016010703)").toJSONString();
        accounts.add(userInfoB);

        YSFUserInfo userInfoC = new YSFUserInfo();
        userInfoC.userId = "晓彤";
        userInfoC.data = userInfoData("晓彤", "13503286027", "xiaotong@163.com", "已认证", "622202******0111015", "七鱼银票(2016010702)").toJSONString();
        accounts.add(userInfoC);

        YSFUserInfo userInfoD = new YSFUserInfo();
        userInfoD.userId = "俞悦";
        userInfoD.data = userInfoData("俞悦", "13509736808", "yuyue@163.com", "已认证", "622202******01111125", null).toJSONString();
        accounts.add(userInfoD);

        YSFUserInfo userInfoE = new YSFUserInfo();
        userInfoE.userId = "雨皓";
        userInfoE.data = userInfoData("雨皓", "15106943618", "yuhao@163.com", "未认证", "未绑定", null).toJSONString();
        accounts.add(userInfoE);

        YSFUserInfo userInfoF = new YSFUserInfo();
        userInfoF.userId = "雨皓";
        userInfoF.data = userInfoData("雨皓2", "15106943618", "yuhao2@163.com", "未认证", "未绑定", null).toJSONString();
        accounts.add(userInfoF);
        return accounts;
    }

    private JSONArray userInfoData(String name, String mobile, String email, String auth, String card, String order) {
        JSONArray array = new JSONArray();
        array.add(userInfoDataItem("real_name", name, false, -1, null, null)); // name
        array.add(userInfoDataItem("mobile_phone", mobile, false, -1, null, null)); // mobile
        array.add(userInfoDataItem("email", email, false, -1, null, null)); // email
        array.add(userInfoDataItem("real_name_auth", auth, false, 0, "实名认证", null));
        array.add(userInfoDataItem("bound_bank_card", card, false, 1, "绑定银行卡", null));
        array.add(userInfoDataItem("recent_order", order, false, 2, "最近订单", null));

        return array;
    }

    private JSONObject userInfoDataItem(String key, Object value, boolean hidden, int index, String label, String href) {
        JSONObject item = new JSONObject();
        item.put("key", key);
        item.put("value", value);
        if (hidden) {
            item.put("hidden", true);
        }
        if (index >= 0) {
            item.put("index", index);
        }
        if (!TextUtils.isEmpty(label)) {
            item.put("label", label);
        }
        if (!TextUtils.isEmpty(href)) {
            item.put("href", href);
        }
        return item;
    }

    private List<YSFUserInfo> removeAccount(List<YSFUserInfo> accounts, YSFUserInfo account) {
        for (YSFUserInfo userInfo : accounts) {
            if (userInfo.userId.equals(account.userId) && userInfo.data.equals(account.data)) {
                accounts.remove(userInfo);
                break;
            }
        }
        return accounts;
    }

    private YSFUserInfo getAccount(List<YSFUserInfo> accounts, String userId) {
        for (YSFUserInfo account : accounts) {
            if (account.userId.equals(userId)) {
                return account;
            }
        }
        return null;
    }

    class AccountAdapter extends BaseAdapter {
        private Context mContext;
        private List<YSFUserInfo> mData;

        public AccountAdapter(Context context) {
            mContext = context;
        }

        public void setData(List<YSFUserInfo> data) {
            mData = data;
        }

        @Override
        public int getCount() {
            return mData.size();
        }

        @Override
        public Object getItem(int position) {
            return mData.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = new TextView(mContext);
                convertView.setPadding(Utils.dp2px(mContext, 16), Utils.dp2px(mContext, 12), Utils.dp2px(mContext, 16), Utils.dp2px(mContext, 12));
                ((TextView) convertView).setTextSize(16);
                ((TextView) convertView).setTextColor(Color.BLACK);
                convertView.setBackgroundResource(R.drawable.setting_item_bg_selector);
            }
            ((TextView) convertView).setText(mData.get(position).userId);
            return convertView;
        }
    }
}
