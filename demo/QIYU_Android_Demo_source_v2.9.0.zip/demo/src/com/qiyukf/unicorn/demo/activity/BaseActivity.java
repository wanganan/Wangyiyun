package com.qiyukf.unicorn.demo.activity;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qiyukf.unicorn.demo.R;
import com.qiyukf.unicorn.demo.utils.permission.PermissionManager;

/**
 * Created by hzwangchenyan on 2015/12/29.
 */
public abstract class BaseActivity extends FragmentActivity {
    private ViewGroup mTitleBar;
    protected Handler mHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHandler = new Handler();
    }

    @Override
    public void setContentView(int layoutResID) {
        View view = LayoutInflater.from(this).inflate(layoutResID, null);
        setContentView(view);
    }

    @Override
    public void setContentView(View view) {
        super.setContentView(realContentView(view));
    }

    @Override
    public void setContentView(View view, ViewGroup.LayoutParams params) {
        super.setContentView(realContentView(view), params);
    }

    private View realContentView(View content) {
        LinearLayout realContent = new LinearLayout(this);
        realContent.setOrientation(LinearLayout.VERTICAL);
        mTitleBar = (ViewGroup) LayoutInflater.from(this).inflate(R.layout.title_bar, null);
        realContent.addView(mTitleBar, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        realContent.addView(content, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        setupTitleBar();
        return realContent;
    }

    private void setupTitleBar() {
        setTitle(getTitle());
        mTitleBar.findViewById(R.id.ll_title_bar_back_area).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public void setTitle(int resId) {
        ((TextView) mTitleBar.findViewById(R.id.tv_title_bar_title)).setText(resId);
    }

    @Override
    public void setTitle(CharSequence title) {
        ((TextView) mTitleBar.findViewById(R.id.tv_title_bar_title)).setText(title);
    }

    public void showTitleBar(boolean show) {
        mTitleBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    public void showBackIcon(boolean show) {
        mTitleBar.findViewById(R.id.iv_title_bar_back).setVisibility(show ? View.VISIBLE : View.GONE);
        mTitleBar.findViewById(R.id.ll_title_bar_back_area).setClickable(show);
    }

    public TextView addTextMenu(int resId) {
        return addTextMenu(getString(resId));
    }

    public TextView addTextMenu(String text) {
        View view = LayoutInflater.from(this).inflate(R.layout.title_bar_menu_text, null);
        TextView tvMenu = (TextView) view.findViewById(R.id.tv_title_bar_menu);
        tvMenu.setText(text);
        addViewMenu(view);
        return tvMenu;
    }

    public ImageView addImageMenu(int resId) {
        View view = LayoutInflater.from(this).inflate(R.layout.title_bar_menu_image, null);
        ImageView ivMenu = (ImageView) view.findViewById(R.id.iv_title_bar_menu);
        ivMenu.setImageResource(resId);
        addViewMenu(view);
        return ivMenu;
    }

    public View addViewMenu(int resId) {
        View view = LayoutInflater.from(this).inflate(resId, null);
        return addViewMenu(view);
    }

    public View addViewMenu(View view) {
        LinearLayout llMenuArea = (LinearLayout) mTitleBar.findViewById(R.id.ll_title_bar_menu_area);
        llMenuArea.addView(view, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        return view;
    }

    public void showSoftKeyboard(final EditText editText) {
        editText.setFocusable(true);
        editText.setFocusableInTouchMode(true);
        editText.requestFocus();
        mHandler.postDelayed(new Runnable() {
            public void run() {
                InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                inputManager.showSoftInput(editText, 0);
            }
        }, 200L);
    }

    public void hideSoftKeyboard() {
        if (getCurrentFocus() != null) {
            InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        PermissionManager.getInstance().notifyPermissionsChange(permissions, grantResults);
    }
}
