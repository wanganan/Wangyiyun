package com.qiyukf.unicorn.demo.application;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;

import com.qiyukf.unicorn.api.ImageLoaderListener;
import com.qiyukf.unicorn.api.UnicornImageLoader;
import com.qiyukf.unicorn.demo.utils.DemoCache;
import com.qiyukf.unicorn.demo.utils.Utils;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import com.squareup.picasso.Target;

import java.util.HashSet;
import java.util.Set;

/**
 * Created by weilv on 16/5/20.
 */
public class PicassoImageLoader implements UnicornImageLoader{
    final Set<Target> protectedFromGarbageCollectorTargets = new HashSet<>();

    @Nullable
    @Override
    public Bitmap loadImageSync(String uri, int width, int height) {
        return null;
    }

    @Override
    public void loadImage(final String uri, final int width, final int height, final ImageLoaderListener listener) {
        final Target mTarget = new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                if (listener != null) {
                    listener.onLoadComplete(bitmap);
                    protectedFromGarbageCollectorTargets.remove(this);
                }
            }

            @Override
            public void onBitmapFailed(Drawable errorDrawable) {
                if (listener != null) {
                    listener.onLoadFailed(null);
                    protectedFromGarbageCollectorTargets.remove(this);
                }
            }

            @Override
            public void onPrepareLoad(Drawable placeHolderDrawable) {

            }
        };
        Utils.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                RequestCreator requestCreator = Picasso.with(DemoCache.context).load(uri).config(Bitmap.Config.RGB_565);
                if (width > 0 && height > 0) {
                    requestCreator = requestCreator.resize(width, height);
                }
                protectedFromGarbageCollectorTargets.add(mTarget);
                requestCreator.into(mTarget);
            }
        });
    }
}
