package com.qiyukf.unicorn.demo.utils;

/**
 * Created by hzwangchenyan on 2015/12/28.
 */
public class Keys {
    public static final String HOST = "appkey.qiyukf.com";
    public static final String PARAM_KEY = "key";
    public static final String PARAM_VERSION = "ver";
    public static final String PARAM_TESTING = "testing";
    public static final String FINANCE = "finance";
    public static final String YIELD = "yield";
    public static final String TERM = "term";
}
