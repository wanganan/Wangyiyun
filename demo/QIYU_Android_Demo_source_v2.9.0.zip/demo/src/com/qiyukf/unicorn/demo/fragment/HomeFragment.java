package com.qiyukf.unicorn.demo.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qiyukf.unicorn.api.Unicorn;
import com.qiyukf.unicorn.api.UnreadCountChangeListener;
import com.qiyukf.unicorn.demo.R;
import com.qiyukf.unicorn.demo.activity.MainActivity;
import com.qiyukf.unicorn.demo.activity.QiyuFinanceActivity;
import com.qiyukf.unicorn.demo.utils.Keys;

/**
 * Created by hzwangchenyan on 2015/12/28.
 */
public class HomeFragment extends BaseFragment implements View.OnClickListener {
    private LinearLayout vgRoot;
    private TextView tvContact;
    private View vView1;
    private View vView2;
    private View vView3;
    private View vView4;
    private String[] title1s = {"七鱼银票(160202)", "七鱼宝(160102)", "七鱼银票(160201)", "七鱼宝(160101)"};
    private String[] title2s = {"6.08", "5.08", "6.08", "5.08"};
    private String[] title3s = {"365", "180", "365", "180"};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        vgRoot = (LinearLayout) view.findViewById(R.id.ll_container);
        return onCreateViewWithTitleBar(view);
    }

    @Override
    protected void init() {
        setupView();
        setListener();

        Unicorn.addUnreadCountChangeListener(mUnreadCountListener, true);
        updateUnreadCount(Unicorn.getUnreadCount());
    }

    private void setupView() {
        showBackIcon(false);
        setTitle(R.string.ysf_activity_qiyu_finance);
        tvContact = addTextMenu(R.string.ysf_contact_service);
        tvContact.setTextColor(getResources().getColor(R.color.red));

        vView1 = LayoutInflater.from(getActivity()).inflate(R.layout.fragment_home_item, null);
        ((TextView) vView1.findViewById(R.id.tv_title_1)).setText(title1s[0]);
        ((TextView) vView1.findViewById(R.id.tv_title_2)).setText(title2s[0]);
        ((TextView) vView1.findViewById(R.id.tv_title_3)).setText(title3s[0]);
        vView1.findViewById(R.id.tv_subtitle).setVisibility(View.GONE);
        vgRoot.addView(vView1);
        vView2 = LayoutInflater.from(getActivity()).inflate(R.layout.fragment_home_item, null);
        ((TextView) vView2.findViewById(R.id.tv_title_1)).setText(title1s[1]);
        ((TextView) vView2.findViewById(R.id.tv_title_2)).setText(title2s[1]);
        ((TextView) vView2.findViewById(R.id.tv_title_3)).setText(title3s[1]);
        vgRoot.addView(vView2);
        vView3 = LayoutInflater.from(getActivity()).inflate(R.layout.fragment_home_item, null);
        ((TextView) vView3.findViewById(R.id.tv_title_1)).setText(title1s[2]);
        ((TextView) vView3.findViewById(R.id.tv_title_2)).setText(title2s[2]);
        ((TextView) vView3.findViewById(R.id.tv_title_3)).setText(title3s[2]);
        vView3.findViewById(R.id.tv_subtitle).setVisibility(View.GONE);
        vgRoot.addView(vView3);
        vView4 = LayoutInflater.from(getActivity()).inflate(R.layout.fragment_home_item, null);
        ((TextView) vView4.findViewById(R.id.tv_title_1)).setText(title1s[3]);
        ((TextView) vView4.findViewById(R.id.tv_title_2)).setText(title2s[3]);
        ((TextView) vView4.findViewById(R.id.tv_title_3)).setText(title3s[3]);
        vgRoot.addView(vView4);
    }

    private void setListener() {
        tvContact.setOnClickListener(this);
        vView1.setOnClickListener(this);
        vView2.setOnClickListener(this);
        vView3.setOnClickListener(this);
        vView4.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v == tvContact) {
            MainActivity.consultService(getActivity(), "https://8.163.com/", "七鱼金融首页", null);
        } else if (v == vView1) {
            Intent intent = new Intent(getContext(), QiyuFinanceActivity.class);
            intent.putExtra(Keys.FINANCE, title1s[0]);
            intent.putExtra(Keys.YIELD, title2s[0]);
            intent.putExtra(Keys.TERM, title3s[0]);
            startActivity(intent);
        } else if (v == vView2) {
            Intent intent = new Intent(getContext(), QiyuFinanceActivity.class);
            intent.putExtra(Keys.FINANCE, title1s[1]);
            intent.putExtra(Keys.YIELD, title2s[1]);
            intent.putExtra(Keys.TERM, title3s[1]);
            startActivity(intent);
        } else if (v == vView3) {
            Intent intent = new Intent(getContext(), QiyuFinanceActivity.class);
            intent.putExtra(Keys.FINANCE, title1s[2]);
            intent.putExtra(Keys.YIELD, title2s[2]);
            intent.putExtra(Keys.TERM, title3s[2]);
            startActivity(intent);
        } else if (v == vView4) {
            Intent intent = new Intent(getContext(), QiyuFinanceActivity.class);
            intent.putExtra(Keys.FINANCE, title1s[3]);
            intent.putExtra(Keys.YIELD, title2s[3]);
            intent.putExtra(Keys.TERM, title3s[3]);
            startActivity(intent);
        }
    }

    private UnreadCountChangeListener mUnreadCountListener = new UnreadCountChangeListener() {
        @Override
        public void onUnreadCountChange(int count) {
            updateUnreadCount(count);
        }
    };

    private void updateUnreadCount(int count) {
        if (count > 99) {
            tvContact.setText(getString(R.string.ysf_contact_service) + "(99+)");
        } else if (count > 0) {
            tvContact.setText(getString(R.string.ysf_contact_service) + "(" + count + ")");
        } else {
            tvContact.setText(R.string.ysf_contact_service);
        }
    }

    @Override
    public void onDestroy() {
        Unicorn.addUnreadCountChangeListener(mUnreadCountListener, false);
        super.onDestroy();
    }
}
