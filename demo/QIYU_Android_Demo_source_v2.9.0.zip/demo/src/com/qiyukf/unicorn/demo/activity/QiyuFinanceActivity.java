package com.qiyukf.unicorn.demo.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.qiyukf.unicorn.demo.R;
import com.qiyukf.unicorn.demo.utils.Keys;

public class QiyuFinanceActivity extends BaseActivity {
    private TextView tvYield;
    private TextView tvTerm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qiyu_finance);

        tvYield = (TextView) findViewById(R.id.tv_yield);
        tvTerm = (TextView) findViewById(R.id.tv_term);

        setTitle(getIntent().getStringExtra(Keys.FINANCE));
        tvYield.setText(getIntent().getStringExtra(Keys.YIELD));
        tvTerm.setText(getIntent().getStringExtra(Keys.TERM));
    }

    public void onClick(View v) {
        if (getIntent().getStringExtra(Keys.FINANCE).contains("七鱼银票")) {
            MainActivity.consultService(this, "https://8.163.com/bill/billList.htm", "七鱼银票",null);
        } else if (getIntent().getStringExtra(Keys.FINANCE).contains("七鱼宝")) {
            MainActivity.consultService(this, "https://8.163.com/dqlc/dqlcList.htm", "七鱼宝",null);
        }
    }
}
