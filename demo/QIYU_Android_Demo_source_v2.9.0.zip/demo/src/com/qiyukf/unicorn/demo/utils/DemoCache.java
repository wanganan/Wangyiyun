package com.qiyukf.unicorn.demo.utils;

import android.content.Context;

import com.qiyukf.unicorn.api.YSFOptions;

/**
 * Created by zhoujianghua on 2015/12/8.
 */
public class DemoCache {
    public static Context context;
    public static YSFOptions ysfOptions; // 七鱼配置选项，设置后如果实在需要中途更换，可以通过此处修改
}
