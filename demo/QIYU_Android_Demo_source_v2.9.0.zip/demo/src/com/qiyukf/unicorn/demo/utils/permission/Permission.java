package com.qiyukf.unicorn.demo.utils.permission;

enum Permission {
    GRANTED,
    DENIED,
    NOT_FOUND
}