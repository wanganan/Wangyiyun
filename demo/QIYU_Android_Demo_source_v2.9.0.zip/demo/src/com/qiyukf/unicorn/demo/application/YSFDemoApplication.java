package com.qiyukf.unicorn.demo.application;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.qiyukf.unicorn.api.SavePowerConfig;
import com.qiyukf.unicorn.api.StatusBarNotificationConfig;
import com.qiyukf.unicorn.api.Unicorn;
import com.qiyukf.unicorn.api.YSFOptions;
import com.qiyukf.unicorn.demo.R;
import com.qiyukf.unicorn.demo.utils.DemoCache;
import com.qiyukf.unicorn.demo.utils.DemoPreferences;
import com.qiyukf.unicorn.demo.utils.Utils;
import com.squareup.picasso.Picasso;

/**
 * Created by zhoujianghua on 2015/8/26.
 */
public class YSFDemoApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        DemoPreferences.init(this);

        //you can use "new FrescoImageLoader()" or "new PicassoImageLoader()"
        if (!Unicorn.init(this, ysfAppId(), ysfOptions(), new UILImageLoader())) {
            Log.w("demo", "init qiyu sdk error!");
        }

        if (inMainProcess(this)) {
            DemoCache.context = getApplicationContext();
            ImageLoader.getInstance().init(ImageLoaderConfiguration.createDefault(this));
            Fresco.initialize(this);
            Picasso.with(this);
        }
    }

    private String ysfAppId() {
        return DemoPreferences.getYsfAppKey();
    }

    private YSFOptions ysfOptions() {
        YSFOptions options = new YSFOptions();
        options.statusBarNotificationConfig = new StatusBarNotificationConfig();
        options.statusBarNotificationConfig.notificationSmallIconId = R.drawable.ic_status_bar_notifier;
        options.savePowerConfig = new SavePowerConfig();
        DemoCache.ysfOptions = options;
        return options;
    }

    public static boolean inMainProcess(Context context) {
        String packageName = context.getPackageName();
        String processName = Utils.getProcessName(context);
        return packageName.equals(processName);
    }
}
