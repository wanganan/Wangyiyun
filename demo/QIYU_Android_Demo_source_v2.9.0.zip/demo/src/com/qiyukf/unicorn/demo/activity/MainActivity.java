package com.qiyukf.unicorn.demo.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.widget.LinearLayout;

import com.qiyukf.nimlib.sdk.NimIntent;
import com.qiyukf.unicorn.api.ProductDetail;
import com.qiyukf.unicorn.api.ConsultSource;
import com.qiyukf.unicorn.api.Unicorn;
import com.qiyukf.unicorn.demo.R;
import com.qiyukf.unicorn.demo.fragment.HomeFragment;
import com.qiyukf.unicorn.demo.fragment.SettingFragment;
import com.qiyukf.unicorn.demo.utils.Utils;

public class MainActivity extends BaseActivity {
    private static final int FRAGMENT_ID_HOME = 0;
    private static final int FRAGMENT_ID_SETTING = 1;
    private LinearLayout llHome;
    private LinearLayout llSetting;
    private HomeFragment mHomeFragment;
    private SettingFragment mSettingFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showTitleBar(false);

        findViews();
        switchFragment(FRAGMENT_ID_HOME);

        parseIntent();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        setIntent(intent);
        parseIntent();
    }

    private void findViews() {
        llHome = (LinearLayout) findViewById(R.id.ysf_tab_home);
        llSetting = (LinearLayout) findViewById(R.id.ysf_tab_setting);
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.ysf_tab_home:
                switchFragment(FRAGMENT_ID_HOME);
                break;
            case R.id.ysf_tab_setting:
                switchFragment(FRAGMENT_ID_SETTING);
                break;
        }
    }

    private void switchFragment(int which) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        if (mSettingFragment != null) {
            ft.hide(mSettingFragment);
        }
        if (mHomeFragment != null) {
            ft.hide(mHomeFragment);
        }
        if (which == FRAGMENT_ID_HOME) {
            llHome.setSelected(true);
            llSetting.setSelected(false);
            if (mHomeFragment == null) {
                mHomeFragment = new HomeFragment();
                ft.add(R.id.ysf_fragment_container, mHomeFragment);
            } else {
                ft.show(mHomeFragment);
            }
        } else if (which == FRAGMENT_ID_SETTING) {
            llHome.setSelected(false);
            llSetting.setSelected(true);
            if (mSettingFragment == null) {
                mSettingFragment = new SettingFragment();
                ft.add(R.id.ysf_fragment_container, mSettingFragment);
            } else {
                ft.show(mSettingFragment);
            }
        }
        ft.commit();
    }

    public static void consultService(final Context context, String uri, String title, ProductDetail productDetail) {
        if (!Unicorn.isServiceAvailable()) {
            // 当前客服服务不可用
            AlertDialog.Builder dialog = new AlertDialog.Builder(context);
            if (!Utils.isNetworkAvailable(context)) {
                // 当前无网络
                dialog.setMessage("网络状况不佳，请重试。");
                dialog.setPositiveButton("确定", null);
            } else {
                // AppKey无效
                dialog.setMessage("未成功绑定 AppKey 无法联系客服");
                dialog.setPositiveButton("去绑定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(context, BindKeyActivity.class);
                        context.startActivity(intent);
                    }
                });
                dialog.setNegativeButton("取消", null);
            }
            dialog.show();
            return;
        }

        // 启动聊天界面
        ConsultSource source = new ConsultSource(uri, title, null);
        source.productDetail = productDetail;
        Unicorn.openServiceActivity(context, staffName(), source);
    }

    private static String staffName() {
        return "七鱼客服";
    }

//    private void trackUser(String url) {
//        Unicorn.trackUserAccess(url, mallWebView.getTitle());
//    }

    /**
     * FC不保存状态，防止重启后fragment重复添加
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
    }

    private void parseIntent() {
        Intent intent = getIntent();
        if (intent.hasExtra(NimIntent.EXTRA_NOTIFY_CONTENT)) {
            consultService(this, null, null, null);
            // 最好将intent清掉，以免从堆栈恢复时又打开客服窗口
            setIntent(new Intent());
        }
    }
}
