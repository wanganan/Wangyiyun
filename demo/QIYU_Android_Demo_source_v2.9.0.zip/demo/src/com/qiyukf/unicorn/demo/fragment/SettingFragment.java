package com.qiyukf.unicorn.demo.fragment;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.qiyukf.unicorn.api.UICustomization;
import com.qiyukf.unicorn.api.Unicorn;
import com.qiyukf.unicorn.api.UnreadCountChangeListener;
import com.qiyukf.unicorn.demo.R;
import com.qiyukf.unicorn.demo.activity.BindKeyActivity;
import com.qiyukf.unicorn.demo.activity.MainActivity;
import com.qiyukf.unicorn.demo.activity.UserInfoActivity;
import com.qiyukf.unicorn.demo.utils.DemoCache;
import com.qiyukf.unicorn.demo.utils.DemoPreferences;

/**
 * Created by hzwangchenyan on 2015/12/28.
 */
public class SettingFragment extends BaseFragment implements View.OnClickListener {
    private LinearLayout llRoot;
    private LinearLayout llUserInfo;
    private LinearLayout llBindKey;
    private LinearLayout llSwitchSkin;
    private LinearLayout llConsult;
    private TextView tvUnread;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        llRoot = (LinearLayout) inflater.inflate(R.layout.fragment_setting, container, false);
        return onCreateViewWithTitleBar(llRoot);
    }

    @Override
    protected void init() {
        showBackIcon(false);
        setTitle("设置");

        setupView();
        setListener();

        Unicorn.addUnreadCountChangeListener(mUnreadCountListener, true);
        updateUnreadCount(Unicorn.getUnreadCount());
    }

    private void setupView() {
        llUserInfo = (LinearLayout) llRoot.findViewById(R.id.ysf_user_info);
        llBindKey = (LinearLayout) llRoot.findViewById(R.id.ysf_bind_key);
        llSwitchSkin = (LinearLayout) llRoot.findViewById(R.id.ysf_switch_shin);
        llConsult = (LinearLayout) llRoot.findViewById(R.id.ysf_consult);
        tvUnread = (TextView) llRoot.findViewById(R.id.tv_unread);

        TextView tvAppKey = (TextView) llRoot.findViewById(R.id.tv_app_key);
        tvAppKey.setText("AppKey：" + DemoPreferences.getYsfAppKey());
    }

    private void setListener() {
        llUserInfo.setOnClickListener(this);
        llBindKey.setOnClickListener(this);
        llSwitchSkin.setOnClickListener(this);
        llConsult.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()) {
            case R.id.ysf_user_info:
                intent = new Intent(getContext(), UserInfoActivity.class);
                startActivity(intent);
                break;
            case R.id.ysf_bind_key:
                intent = new Intent(getContext(), BindKeyActivity.class);
                startActivity(intent);
                break;
            case R.id.ysf_switch_shin:
                DemoCache.ysfOptions.uiCustomization = DemoCache.ysfOptions.uiCustomization == null ? uiCustomization() : null;
                Toast.makeText(getContext(), "切换成功", Toast.LENGTH_SHORT).show();
                break;
            case R.id.ysf_consult:
                MainActivity.consultService(getActivity(), null, null,null);
                break;
        }
    }

    private UnreadCountChangeListener mUnreadCountListener = new UnreadCountChangeListener() {
        @Override
        public void onUnreadCountChange(int count) {
            updateUnreadCount(count);
        }
    };

    private void updateUnreadCount(int count) {
        tvUnread.setVisibility(count > 0 ? View.VISIBLE : View.GONE);
        if (count > 99) {
            tvUnread.setText("99+");
        } else if (count > 0) {
            tvUnread.setText(String.valueOf(count));
        }
    }

    private UICustomization uiCustomization() {
        // 以下示例的图片均无版权，请勿使用
        UICustomization customization = new UICustomization();
        customization.titleBarStyle = 1;
        customization.titleBackgroundResId = R.drawable.my_ysf_title_bar_bg;

        customization.topTipBarBackgroundColor = 0xFFDCF2F5;
        customization.topTipBarTextColor = 0xFF4E97D9;

        customization.msgBackgroundUri = "assets://" + "msg_bg.png";

        customization.leftAvatar = "drawable://" + R.drawable.my_avatar_staff;
        customization.rightAvatar = "drawable://" + R.drawable.my_avatar_user;

        customization.msgItemBackgroundLeft = R.drawable.my_message_item_left_selector;
        customization.msgItemBackgroundRight = R.drawable.my_message_item_right_selector;

        customization.textMsgColorLeft = Color.BLACK;
        customization.textMsgColorRight = Color.WHITE;

        customization.audioMsgAnimationLeft = R.drawable.my_audio_animation_list_left;
        customization.audioMsgAnimationRight = R.drawable.my_audio_animation_list_right;

        customization.tipsTextColor = 0xFF76838F;

        customization.buttonBackgroundColorList = R.color.my_button_color_state_list;
        return customization;
    }

    @Override
    public void onDestroy() {
        Unicorn.addUnreadCountChangeListener(mUnreadCountListener, false);
        super.onDestroy();
    }
}
