package com.qiyukf.unicorn.demo.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.qiyukf.unicorn.demo.R;
import com.qiyukf.unicorn.demo.utils.Keys;

public class InputKeyActivity extends BaseActivity implements View.OnClickListener, TextWatcher {
    private EditText etAppKey;
    private TextView tvInputIllegal;
    private Button btnOk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_key);

        etAppKey = (EditText) findViewById(R.id.et_app_key);
        tvInputIllegal = (TextView) findViewById(R.id.tv_input_illegal);
        btnOk = (Button) findViewById(R.id.btn_ok);
        etAppKey.addTextChangedListener(this);
        btnOk.setOnClickListener(this);

        showSoftKeyboard(etAppKey);
    }

    @Override
    public void onClick(View v) {
        if (v == btnOk) {
            String key = etAppKey.getText().toString();
            Intent data = new Intent();
            data.putExtra(Keys.PARAM_KEY, key);
            setResult(RESULT_OK, data);
            finish();
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
        String str = s.toString();
        if (str.contains(" ")) {
            str = str.replace(" ", "");
        }
        if (str.length() > 40) {
            str = str.substring(0, 40);
        }
        if (str.length() != s.length()) {
            etAppKey.setText(str);
            etAppKey.setSelection(etAppKey.length());
        }
        tvInputIllegal.setVisibility(etAppKey.length() > 32 ? View.VISIBLE : View.GONE);
        if (etAppKey.length() != 32) {
            btnOk.setEnabled(false);
        } else {
            btnOk.setEnabled(true);
        }
    }
}
