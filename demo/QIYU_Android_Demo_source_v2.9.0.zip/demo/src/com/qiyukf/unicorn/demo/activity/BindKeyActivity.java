package com.qiyukf.unicorn.demo.activity;

import android.app.ActivityManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.google.zxing.activity.CaptureActivity;
import com.qiyukf.unicorn.api.Diagnosis;
import com.qiyukf.unicorn.demo.R;
import com.qiyukf.unicorn.demo.utils.DemoPreferences;
import com.qiyukf.unicorn.demo.utils.Keys;
import com.qiyukf.unicorn.demo.utils.permission.PermissionResultAction;
import com.qiyukf.unicorn.demo.utils.permission.PermissionUtil;

import java.util.List;

public class BindKeyActivity extends BaseActivity implements View.OnClickListener {
//    private final String[] keys_test = {
//            "小凤", "044865c94981c048609d5c94c1ae9c6d",
//            "跨江", "1064deea1c3624c9ee26d1de5ce8481f",
//            "阿毛", "58914c837a84dbbfe21eaaa356b1cf74",
//            "QA", "49c87881861b9d275fdebb136baf3713"
//    };
//
//    private final String[] keys_rel = {
//            "online0", "0c6ad4e66106bf277eac233909926ca5",
//            "online1", "0e722cd4c5d8aea0ec03dfec7483846e",
//            "online2", "ed1d17dddcb7331388b07bf83f284bad",
//            "online3", "4ba53a88957fb27300d38fde30e0dc0f",
//            "online4", "3858be3c20ceb6298575736cf27858a7"
//    };

    public static final int REQUEST_CAPTURE = 0;
    public static final int REQUEST_INPUT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bind_key);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ysf_scan_to_bind:
                PermissionUtil.requestCameraPermission(this, new PermissionResultAction() {
                    @Override
                    public void onGranted() {
                        Intent intent = new Intent(BindKeyActivity.this, CaptureActivity.class);
                        startActivityForResult(intent, REQUEST_CAPTURE);
                    }

                    @Override
                    public void onDenied(String permission) {
                        Toast.makeText(BindKeyActivity.this, "没有权限，无法打开摄像头！", Toast.LENGTH_SHORT).show();
                    }
                });

                break;
            case R.id.ysf_input_to_bind:
                Intent intent = new Intent(this, InputKeyActivity.class);
                startActivityForResult(intent, REQUEST_INPUT);
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK || data == null) {
            return;
        }
        if (requestCode == REQUEST_CAPTURE) {
            String result = data.getStringExtra(CaptureActivity.SCAN_RESULT);
            Uri uri = Uri.parse(result);
            String appKey = uri.getQueryParameter(Keys.PARAM_KEY);
            if (!Keys.HOST.equals(uri.getHost()) || TextUtils.isEmpty(appKey)) {
                Toast.makeText(this, "二维码错误", Toast.LENGTH_SHORT).show();
                return;
            }
            String version = uri.getQueryParameter(Keys.PARAM_VERSION);
            String testing = uri.getQueryParameter(Keys.PARAM_TESTING);
            int env = TextUtils.isEmpty(testing) ? 0 : Integer.parseInt(testing);
            applyKey(env, appKey);
        } else if (requestCode == REQUEST_INPUT) {
            String appKey = data.getStringExtra(Keys.PARAM_KEY);
            applyKey(0, appKey);
        }
    }

    private void applyKey(int dev, String key) {
        Diagnosis.setDevServer(dev);
        DemoPreferences.saveDevTag(dev == 1);
        DemoPreferences.saveYsfAppKey(key);

        Toast.makeText(this, "绑定成功，即将重启…", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                int pid = 0, corePid = 0;
                ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                List<ActivityManager.RunningAppProcessInfo> mRunningProcess = activityManager.getRunningAppProcesses();
                for (ActivityManager.RunningAppProcessInfo amProcess : mRunningProcess) {
                    if (getPackageName().equals(amProcess.processName)) {
                        pid = amProcess.pid;
                    } else if ((getPackageName() + ":core").equals(amProcess.processName)) {
                        corePid = amProcess.pid;
                    }
                }
                Process.killProcess(corePid);
                Process.killProcess(pid);
            }
        }, 500);
    }
}
