package com.qiyukf.unicorn.demo.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.qiyukf.unicorn.demo.R;

/**
 * Created by hzwangchenyan on 2015/12/29.
 */
public abstract class BaseFragment extends Fragment {
    private ViewGroup mTitleBar;
    protected Handler mHandler;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHandler = new Handler();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init();
    }

    protected abstract void init();

    public View onCreateViewWithTitleBar(View content) {
        LinearLayout realContent = new LinearLayout(getActivity());
        realContent.setOrientation(LinearLayout.VERTICAL);
        mTitleBar = (ViewGroup) LayoutInflater.from(getActivity()).inflate(R.layout.title_bar, null);
        realContent.addView(mTitleBar, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        realContent.addView(content, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        setupTitleBar();
        return realContent;
    }

    private void setupTitleBar() {
        setTitle(getActivity().getTitle());
        mTitleBar.findViewById(R.id.ll_title_bar_back_area).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
    }

    public void setTitle(int resId) {
        ((TextView) mTitleBar.findViewById(R.id.tv_title_bar_title)).setText(resId);
    }

    public void setTitle(CharSequence title) {
        ((TextView) mTitleBar.findViewById(R.id.tv_title_bar_title)).setText(title);
    }

    public void showTitleBar(boolean show) {
        mTitleBar.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    public void showBackIcon(boolean show) {
        mTitleBar.findViewById(R.id.iv_title_bar_back).setVisibility(show ? View.VISIBLE : View.GONE);
        mTitleBar.findViewById(R.id.ll_title_bar_back_area).setClickable(show);
    }

    public TextView addTextMenu(int resId) {
        return addTextMenu(getString(resId));
    }

    public TextView addTextMenu(String text) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.title_bar_menu_text, null);
        TextView tvMenu = (TextView) view.findViewById(R.id.tv_title_bar_menu);
        tvMenu.setText(text);
        addViewMenu(view);
        return tvMenu;
    }

    public ImageView addImageMenu(int resId) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.title_bar_menu_image, null);
        ImageView ivMenu = (ImageView) view.findViewById(R.id.iv_title_bar_menu);
        ivMenu.setImageResource(resId);
        addViewMenu(view);
        return ivMenu;
    }

    public View addViewMenu(int resId) {
        View view = LayoutInflater.from(getContext()).inflate(resId, null);
        return addViewMenu(view);
    }

    public View addViewMenu(View view) {
        LinearLayout llMenuArea = (LinearLayout) mTitleBar.findViewById(R.id.ll_title_bar_menu_area);
        llMenuArea.addView(view, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
        return view;
    }
}
