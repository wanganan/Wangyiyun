package com.qiyukf.unicorn.demo.utils.permission;

import android.Manifest;
import android.app.Activity;
import android.content.Context;

/**
 * Created by weilv on 16/6/14.
 */
public class PermissionUtil {
    private static Context appContext;

    public static void init(Context context) {
        appContext = context.getApplicationContext();
    }

    public static void requestStoragePermission(Activity activity) {
        if (null == activity) {
            return;
        }
        boolean hasPermission = PermissionManager.getInstance().hasPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!hasPermission) {
            PermissionManager.getInstance().requestPermissionsIfNecessaryForResult(
                    activity,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    null);
        }
    }

    public static void requestCameraPermission(Activity activity,PermissionResultAction permissionResultAction) {
        if (null == activity) {
            return;
        }
        PermissionManager.getInstance().requestPermissionsIfNecessaryForResult(
                    activity,
                    new String[]{Manifest.permission.CAMERA}, permissionResultAction);
    }

    public static void requestPermissions(Activity activity) {
        if (null == activity) {
            return;
        }
        boolean hasPermission = PermissionManager.getInstance().hasPermission(activity, Manifest.permission.RECORD_AUDIO)
                && PermissionManager.getInstance().hasPermission(activity, Manifest.permission.CAMERA)
                && PermissionManager.getInstance().hasPermission(activity, Manifest.permission.READ_PHONE_STATE)
                && PermissionManager.getInstance().hasPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (!hasPermission) {
            PermissionManager.getInstance().requestPermissionsIfNecessaryForResult(
                    activity,
                    new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.READ_PHONE_STATE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    null);
        }
    }

    public static boolean hasCameraPermission() {
        if (null == appContext) {
            return false;
        }
        return PermissionManager.getInstance().hasPermission(appContext, Manifest.permission.CAMERA);
    }

    public static boolean hasStoragePermission() {
        if (null == appContext) {
            return false;
        }
        return PermissionManager.getInstance().hasPermission(appContext, Manifest.permission.READ_EXTERNAL_STORAGE)
                && PermissionManager.getInstance().hasPermission(appContext, Manifest.permission.WRITE_EXTERNAL_STORAGE);
    }

    public static boolean hasAudioPermission() {
        if (null == appContext) {
            return false;
        }
        return PermissionManager.getInstance().hasPermission(appContext, Manifest.permission.RECORD_AUDIO);
    }
    public static boolean hasPhonePermission() {
        if (null == appContext) {
            return false;
        }
        return PermissionManager.getInstance().hasPermission(appContext, Manifest.permission.READ_PHONE_STATE);
    }

}
